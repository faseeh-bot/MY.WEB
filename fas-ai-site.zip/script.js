// Set year in footer
document.getElementById("year").textContent = new Date().getFullYear();