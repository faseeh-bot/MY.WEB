# fas.ai — Personal Portfolio Website

This is a simple, responsive website for fas.ai.  
It is 100% GitHub Pages–ready with **no build step**.

## Deployment on GitHub Pages
1. Create a new repo on GitHub (e.g., `fas-ai-site`).
2. Upload these files (`index.html`, `styles.css`, `script.js`).
3. Go to **Settings → Pages**.
4. Under *Source*, select **main branch** and folder **/(root)**.
5. Save — your site will be live at:

```
https://<your-username>.github.io/fas-ai-site/
```